document.body.style.cssText = "font-family: sans-serif; padding: 24px; margin: 0; background: #fff; color: #222;";
const el = document.createElement("div");
el.id = "hello";
el.textContent = "Hello from a third-party app!";
document.body.append(el);
